let score=0;
function update(){document.getElementById('score').textContent='คะแนน: '+score;}
function start(){
 const g=document.getElementById('game');
 g.innerHTML='<h2>ด่านที่ 1 นับแอปเปิล</h2><p>🍎🍎🍎 มีกี่ผล?</p>';
 [2,3,4].forEach(n=>{
  const d=document.createElement('div');
  d.className='choice';
  d.textContent=n;
  d.onclick=()=>check(n);
  g.appendChild(d);
 });
}
function check(n){
 if(n===3){score+=10;alert('เก่งมาก! +10 คะแนน');}
 else alert('ลองอีกครั้ง');
 update();
}
update();
